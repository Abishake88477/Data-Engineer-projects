# NewGitproject — Abishake Singaravelu

> **Azure Data Engineer · 7+ Years · Enterprise ETL / Lakehouse Architecture**

This repository holds the reference implementations, sample notebooks and pipeline configurations for the six data-engineering projects showcased on my portfolio site. Each project is a distilled, sanitised version of production work delivered for real clients (details below) — with no proprietary data.

---

## Portfolio Projects

| # | Project | Client | Tech Stack |
|---|---------|--------|------------|
| 01 | [Azure Lakehouse Pipeline — Clearsprings Ready Homes](./01-azure-lakehouse-clearsprings/) | Nationwide Accommodation Ltd | Databricks · ADF · PySpark · ADLS · Snowflake |
| 02 | [Metadata-Driven ETL Framework](./02-metadata-driven-etl-framework/) | Nationwide Accommodation Ltd | ADF · Databricks · PySpark |
| 03 | [Master PySpark Consolidation Job](./03-master-pyspark-consolidation/) | Nationwide Accommodation Ltd | PySpark · Spark SQL · ADLS |
| 04 | [Enterprise ADF Pipelines — Stay Belvedere Hotels](./04-adf-pipelines-stay-belvedere/) | Marketplace Direct Ltd | ADF · Databricks · PySpark |
| 05 | [Reusable PySpark Component Library](./05-reusable-pyspark-components/) | Marketplace Direct Ltd | PySpark · Python · ADF |
| 06 | [Healthcare ETL Testing Framework — NHS Trust](./06-etl-testing-framework-nhs/) | Princess Alexandra Hospital NHS Trust | SQL · Hive · Hadoop · HBase · Impala |

---

## About the engineer

**Abishake Singaravelu**
Azure Data Engineer · Thiruvarur, Tamil Nadu, India — Open to Remote / Global

- Email — abishake.88477@gmail.com
- Phone — +91 74182 88477
- LinkedIn — https://www.linkedin.com/in/abishake-singaravelu
- Portfolio — (see the live portfolio site)

## Highlights

- **7+ years** designing enterprise-scale ETL/ELT pipelines on Azure Databricks + Azure Data Factory
- Processes **3+ TB / day** across ADLS, Snowflake and Web APIs
- Reduced pipeline onboarding time by **45%** via a metadata-driven framework
- Reconciled data accuracy improved to **99.8%**
- Built Medallion (Bronze / Silver / Gold) Lakehouse architectures used by 5 business teams

---

## Repository layout

```
NewGitproject/
├── README.md                              (this file)
├── 01-azure-lakehouse-clearsprings/
├── 02-metadata-driven-etl-framework/
├── 03-master-pyspark-consolidation/
├── 04-adf-pipelines-stay-belvedere/
├── 05-reusable-pyspark-components/
└── 06-etl-testing-framework-nhs/
```

Each project folder contains its own `README.md` describing the architecture, tech stack, business impact and (where useful) representative code snippets or notebook stubs.

---

## Licence
MIT
